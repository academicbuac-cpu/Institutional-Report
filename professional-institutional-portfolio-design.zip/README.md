# Busthanul Uloom Arabic College - Website

A professional institutional presentation website for Busthanul Uloom Arabic College with a built-in admin panel.

## Features

- **30+ Presentation Slides**: Complete institutional overview with animated transitions
- **Admin Panel**: Edit all content and images without touching code
- **Responsive Design**: Works on all devices
- **Professional Styling**: Islamic-inspired design with green and gold color scheme

## Admin Panel

Access the admin panel by clicking the ⚙️ gear icon in the bottom-right corner.

### Editing Content

1. **Select a section** from the left sidebar
2. **Edit text fields** - All headings, descriptions, and content are editable
3. **Upload images** - Click "Upload Image" to add photos
4. **Add/Remove items** - Use the plus (+) and trash (️) buttons to manage lists
5. **Save changes** - Click "Save" in the top-right corner

Changes are saved to your browser's localStorage and persist across page reloads.

## Deploying Changes to Production

The admin panel saves changes locally. To make changes visible to all visitors:

### Method 1: Export/Import JSON

1. **Export your changes**:
   - Open Admin Panel
   - Click "Export Data (JSON)" in the left sidebar
   - A `site-data.json` file will download

2. **Update your repository**:
   ```bash
   # Replace the existing file in your project
   cp ~/Downloads/site-data.json ./public/site-data.json
   
   # Commit and push to GitHub
   git add public/site-data.json
   git commit -m "Update site content"
   git push
   ```

3. **Vercel will automatically rebuild** and deploy your changes

### Method 2: Cloud Sync via JSONBin.io (Instant Updates)

**Best for**: Instant updates without waiting for Vercel rebuilds.

#### Setup (One Time Only)

**Step 1: Sign Up for JSONBin.io**
1. Go to **[https://jsonbin.io](https://jsonbin.io)**
2. Click **"Sign Up"** (top-right)
3. Sign up with email or GitHub
4. Verify your email

**Step 2: Create Your First Bin**
1. Click **"+ Create Bin"** (top-right)
2. Delete the default content in the editor
3. Export your current data from admin panel (JSON) and paste it here
4. Click **"Create Bin"**

**Step 3: Get Your Bin ID**
1. Look at the URL: `https://jsonbin.io/b/XXXXXXXXXXXXXXXXXXXXXX`
2. Copy the long alphanumeric ID (e.g., `66f3a2b4c8d9e1f2a3b4c5d6`)

**Step 4: Get Your Master API Key**
1. Click your **profile icon** → **"API Keys"**
2. Copy your **Master Key** (starts with `$2a$10$...`)

#### Using Cloud Sync

1. **Open Admin Panel** → Click **"Cloud Sync"** in the sidebar
2. **Paste Bin ID** and **API Key**
3. Click **"Save Credentials"** (saved to your browser)
4. **Load from Cloud**: Pulls latest data from JSONBin
5. **Save to Cloud**: Pushes current edits to JSONBin
6. **Download Cloud Config**: Downloads `cloud-config.json` file
7. **Replace** `public/cloud-config.json` in your GitHub repo with the downloaded file
8. **Commit and push** to GitHub
9. Vercel rebuilds → **all visitors now auto-load from JSONBin!**

#### Updating Content After Setup

Once cloud-config.json is committed:
1. Edit content in admin panel
2. Click **"Save to Cloud"** (instant, no GitHub needed!)
3. **All visitors see changes on next page load** (no Vercel rebuild required!)

### Method 3: Direct JSON Edit

For advanced users, you can directly edit `public/site-data.json` in your repository with any JSON editor.

## Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Project Structure

```
src/
├── components/
│   ├── admin/          # Admin panel components
│   └── slides/         # Individual slide components
├── context/
│   └── DataContext.tsx # Global state management
── hooks/
│   └── useInView.ts    # Intersection observer hook
└── App.tsx             # Main application

public/
├── images/             # Static images
└── site-data.json      # Editable site content
```

## Technology Stack

- **React 19** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS 4** for styling
- **Recharts** for data visualization
- **Lucide React** for icons
- **LocalStorage** for admin data persistence

## License

All rights reserved.
